import React from "react";


export function Tooltip(props) {
    const {d, left, top} = props;
    //console.log(d);
    if (left === null) {
        return <div></div>;
    } else {
        const divStyle = {
            position: "absolute",
            textAlign: "top",
            width: "100px",
            height: "80px",
            font: "12px sans-serif",
            background: "moccasin",
            border: "1px outset black",
            // borderRadius: "8px",
            pointerEvents: "none",
            left: `${left}px`,
            top: `${top}px`,
        };
        return <div style={divStyle} >
            <p>{d.ancestors().reverse().slice(1).map((dataitem, idx) => {
                console.log(dataitem);
                return dataitem.data.name}
                )
                .join("\n")+"\ncount:"+d.data.count}</p>
            </div>
    };  
}

/*<p>{d.ancestors().reverse().slice(1).map((d, idx) => d.data.name)
                .join("\n")+"\ninfected:"+d.data.infections+
                "\nsymtomtatic:"+d.data.symptomatic+
                "\nasymtomtatic:"+d.data.asymptomatic}</p>*/