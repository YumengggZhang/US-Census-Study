import React from "react";
import { max } from "d3";
import { XAxis, YAxis } from "./axes";
import { Scales } from "./scale";
import { Bars } from './bars';
import * as d3 from "d3"

// <BarChart offsetX={WIDTH+margin.gap} offsetY={margin.top} height={height/2} width={width}  
// d={selectedNode}/>
export function BarChart (props) {
    const {offsetX, offsetY, height, width, d}=props;
    if (d !== null) {
        var gdata_group_by_continent = d3.group(d.data.group,  
            d => d.continent)
        var total_num = d.data.group.length
        var continent_df = []
        gdata_group_by_continent.forEach(function(d, i){
            continent_df.push({popultaion: d.length ,country: i, percent: Math.round((d.length/total_num)*100)})
        })
        console.log(continent_df)
    
        if (continent_df.length === 1){
            var gdata_group_by_country = d3.group(d.data.group,  
                d => d.Birthplace)
            var country_df = []
            gdata_group_by_country.forEach(function(d, i){
                // console.log(d.length, i)
                country_df.push({popultaion: d.length ,country: i})
            })
            // console.log(country_df)
            var xScale = Scales.band(country_df.map(d => d.country), width, 0);
            var yScale = Scales.linear(0,max(country_df, d=>d.popultaion),height, 0);
            //console.log(yScale)
            return <g transform={`translate(${offsetX}, ${offsetY})`}>
            <Bars xScale={xScale} yScale={yScale} height={height}
                d={d}/>
            <XAxis xScale={xScale} height={height} width={width} axisLable={"country"}/>
            <YAxis yScale={yScale} height={height} axisLable={"population"}/>
            
        </g>
        }

        if (continent_df.length !== 1){
            // console.log(continent_df)
            var xScale = Scales.band(continent_df.map(d => d.country), width, 0);
            var yScale = Scales.linear(0,max(continent_df, d=>d.popultaion),height, 0);
            //console.log(yScale)
            return <g transform={`translate(${offsetX}, ${offsetY})`}>
            <Bars xScale={xScale} yScale={yScale} height={height}
                d={d}/>
            <XAxis xScale={xScale} height={height} width={width} axisLable={"continent"}/>
            <YAxis yScale={yScale} height={height} axisLable={"population"}/>
            </g>
        }
    }
    // const xScale = Scales.band(data.map(d => d.station), width, 0);
    // const yScale = Scales.linear(0,max(data, d=>d.start),height, 0); 
    return <g></g>
}