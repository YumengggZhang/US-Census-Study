import React from "react";
import * as d3 from "d3"

export function Bars(props){
    const {xScale, yScale, height, d}=props;
    if (d !== null) {
        // console.log("abab", d.data.group.length);
        var gdata_group_by_continent = d3.group(d.data.group,  
            d => d.continent)
        var continent_df = []
        gdata_group_by_continent.forEach(function(d, i){
            // console.log(d.length, i)
            continent_df.push({popultaion: d.length ,country: i})
        })
        // console.log(continent_df.length)

        if (continent_df.length === 1){
            var gdata_group_by_country = d3.group(d.data.group,  
                d => d.Birthplace)
            var country_df = []
            gdata_group_by_country.forEach(function(d, i){
                // console.log(d.length, i)
                country_df.push({popultaion: d.length ,country: i})
            })
            // console.log(country_df)
            return <g>
            {country_df.map( d =>
            <rect key={d.country} x={xScale(d.country)} y={yScale(d.popultaion)}
            width={xScale.bandwidth()} height={height-yScale(d.popultaion)} fill={"#eef5fc"} stroke="black" 
            />)}
        </g>
        }
        if (continent_df.length !== 1){
            // console.log(continent_df)
            return <g>
            {continent_df.map( d =>
            <rect key={d.country} x={xScale(d.country)} y={yScale(d.popultaion)}
            width={xScale.bandwidth()} height={height-yScale(d.popultaion)} fill={"steelblue"} stroke="black" 
            />)}
        </g>
        }
    }
    // const {d, left, top} = props;
    // if (d !== null) {
    //     console.log("abab", d.data.group[0].Age);
    //     return <g>
    //     { data.map( d =>
    //     <rect key={d.country} x={xScale(d.country)} y={yScale(d.start)}
    //     width={xScale.bandwidth()} height={height-yScale(d.start)} fill={"steelblue"} stroke="black" 
    //     />)}
    // </g>
    // }
    return <g></g>
}