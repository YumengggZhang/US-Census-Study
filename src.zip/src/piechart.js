import React, { useEffect } from 'react';
import * as d3 from 'd3';

export function ArcEducation(props) {
  const {index,data,createArc, colors, format,radius} = props;

  function findCordinate(d){
    var c = createArc.centroid(d),
    x = c[0],
    y = c[1],
    // pythagorean theorem for hypotenuse
    h = Math.sqrt(x*x + y*y),
    midAngle = d.endAngle < Math.PI ? d.startAngle/2 + d.endAngle/2 : d.startAngle/2  + d.endAngle/2 + Math.PI;
  return "translate(" + (x/h * radius*1.2) +  ',' + (y/h * radius*1.2) +  ")rotate(-90) rotate(" +(midAngle * 180/Math.PI)+ ")";}
  
  // set Label for pie piece
  if (data.data.percent<2){var labelName = ''} else{var labelName = data.data.educationLevel}
  //create percentage of pie piece
  if (data.data.percent<2){var percentage = ''} else{var percentage = data.data.percent+'%'}
  
  return(
  <g key={index} className="arc">
    <text
    style={{fontFamily:"verdana",fontSize:'20'}}
    transform={'translate(-80,0)'}
    >
      Education Status
    </text>
    <path className="arc" d={createArc(data)} fill={colors(index)} />
    <text 
      transform={findCordinate(data)}
      textAnchor="middle"
      fill="black"
      fontSize="16"
    >
    {labelName} 
    </text>
    <text
      transform={`translate(${createArc.centroid(data)})`}
      textAnchor="middle"
      fill="black"
      fontSize="18"
    >
    {percentage}  
    </text>
  </g>)
};
export function ArcOccupation(props) {
  const {index,data,createArc, colors, format,radius} = props;

  function findCordinate(d){
    var c = createArc.centroid(d),
    x = c[0],
    y = c[1],
    // pythagorean theorem for hypotenuse
    h = Math.sqrt(x*x + y*y),
    midAngle = d.endAngle < Math.PI ? d.startAngle/2 + d.endAngle/2 : d.startAngle/2  + d.endAngle/2 + Math.PI;
  return "translate(" + (x/h * radius*1.2) +  ',' + (y/h * radius*1.2) +  ")rotate(-90) rotate(" + (midAngle * 180/Math.PI) + ")";} 
  // set Label for pie piece
  if (data.data.percent<2){var labelName = ''} else{var labelName = data.data.occupation}
  if (data.data.percent<2){var percentage = ''} else{var percentage = data.data.percent+'%'}
  // var percent = Math.round(data.value/data.data.total_num);
  
  return(
  <g key={index} className="arc">
    <text
    style={{fontFamily:"verdana",fontSize:'20'}}
    transform={'translate(-85,0)'}
    >
      {'Occupation Detail'}
    </text>
    <path className="arc" d={createArc(data)} fill={colors(index)} />
    <text 
      transform={findCordinate(data)}
      textAnchor="middle"
      fill="black"
      fontSize="15"
    >
    {labelName} 
    {/* {' '+(percentage)+'%'} */}
    </text>
    <text
      transform={`translate(${createArc.centroid(data)})`}
      textAnchor="middle"
      fill="black"
      fontSize="18"
    >
    {percentage}  
    </text>
  </g>)
}
export function PieChart(props) {
  const {rawdata,selectedNode,width,height,outerRadius, innerRadius,margin} = props;
  const temdata = [{ label: 'Apples', value: 10 }, { label: 'Oranges', value: 20 },{ label: 'Cookie', value: 30 }, { label: 'Coffee', value: 20 }];

  // console.log(selectedNode)
  if (selectedNode !== null) {
    var gdata_group_by_education = d3.group(selectedNode.data.group, d => d.educationLevel)
    var total_num = selectedNode.data.group.length
    var education = []
    console.log(gdata_group_by_education)
      gdata_group_by_education.forEach(function(d, i){
        // console.log(d.length, i)
        education.push({popultaion: d.length ,educationLevel: i, percent: Math.round((d.length/total_num)*100)})
    })}

  
  if (selectedNode !== null) {
      // console.log("abab", selectedNode.data.group);
      var gdata_group_by_occupation = d3.group(selectedNode.data.group, d => d.Occupation)
      var total_num = selectedNode.data.group.length
      var occupation = []
      console.log(gdata_group_by_occupation)
      gdata_group_by_occupation.forEach(function(d, i){
          occupation.push({popultaion: d.length ,occupation: i, percent: Math.round((d.length/total_num)*100)})
      })}

  const createPie = d3
    .pie()
    .value(d => d.popultaion)
    .sort(null);

  const createArc = d3
    .arc()
    .innerRadius(innerRadius)
    .outerRadius(outerRadius);

  const colors = d3.scaleOrdinal(d3.schemeSet3);

  const outerArc = d3
  .arc()
	.innerRadius(outerRadius * 0.9)
	.outerRadius(outerRadius * 0.9)

  const format = d3.format(".2f");

  if (selectedNode !== null){
    var arcdata1 = createPie(education),
    arcdata2 = createPie(occupation)} 
  else{var arcdata1 = createPie(temdata),
          arcdata2 = createPie(temdata)};
  
  return ( 
  <svg width={width*2} height={height*2}>
    <g transform={`translate(${width-outerRadius*2-margin.right*2.5} ${height/2+outerRadius+margin.bottom*2})`}>
      {arcdata1.map((d, i) => (       
        // draw two pie charts
        <ArcEducation      
          key={i} 
          index={i}
          data={d}
          createArc={createArc}
          colors={colors}
          format={format}
          radius = {outerRadius}
          // label = {'edcationLevel'}
        />
      ))}
    </g>
    <g transform={`translate(${width-outerRadius+margin.right*1.8} ${height/2+outerRadius+margin.bottom*2})`}>
      {arcdata2.map((d, i) => (       
        <ArcOccupation      
          key={i}
          index={i}
          data={d}
          createArc={createArc}
          colors={colors}
          format={format}
          radius = {outerRadius}
          // label = {'occupation'}
        />
      ))}
    </g>
  </svg>)
  }
